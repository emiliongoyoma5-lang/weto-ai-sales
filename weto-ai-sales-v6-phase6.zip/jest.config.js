module.exports = {
  moduleFileExtensions: ['js', 'json', 'ts'],
  rootDir: '.',
  testRegex: '.*\\.spec\\.ts$',
  transform: {'^.+\\.(t|j)s$': 'ts-jest'},
  testEnvironment: 'node',
  collectCoverageFrom: ['src/**/*.ts']
};
